package com.example.hrmanagement.ui.attendance

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.hrmanagement.R
import com.example.hrmanagement.data.RecentActivity

class AttendanceRecordAdapter :
    RecyclerView.Adapter<AttendanceRecordAdapter.ViewHolder>() {

    private val items = mutableListOf<RecentActivity>()

    fun submitList(list: List<RecentActivity>) {
        items.clear()
        items.addAll(list)
        notifyDataSetChanged()
    }

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvDate: TextView = view.findViewById(R.id.tvDate)
        val tvIn: TextView = view.findViewById(R.id.tvIn)
        val tvStatus: TextView = view.findViewById(R.id.tvStatus)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_attendance_record, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]

        holder.tvDate.text = item.title
        holder.tvIn.text = item.subtitle
        holder.tvStatus.text = item.type

        // Style tag color depending on status
        when (item.type.uppercase()) {
            "PRESENT" -> holder.tvStatus.setBackgroundResource(R.drawable.tag_present)
            "LATE" -> holder.tvStatus.setBackgroundResource(R.drawable.tag_late)
            "ABSENT" -> holder.tvStatus.setBackgroundResource(R.drawable.tag_absent)
        }
    }
}
