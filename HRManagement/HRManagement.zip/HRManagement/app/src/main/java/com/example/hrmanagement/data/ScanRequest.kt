package com.example.hrmanagement.data

// Body sent when scanning a QR token
data class ScanRequest(
    val token: String
)
