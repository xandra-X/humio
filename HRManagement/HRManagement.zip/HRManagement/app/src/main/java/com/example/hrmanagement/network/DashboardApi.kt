package com.example.hrmanagement.network

import com.example.hrmanagement.data.CheckInOutRequest
import com.example.hrmanagement.data.CheckInOutResponse
import com.example.hrmanagement.data.DashboardResponse
import com.example.hrmanagement.data.ScanRequest
import com.example.hrmanagement.data.ScanResponse
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.GET

interface DashboardApi {

    @GET("/api/dashboard")
    suspend fun getDashboard(
        @Header("Authorization") bearerToken: String
    ): DashboardResponse

    @POST("/api/dashboard/check")
    suspend fun checkInOut(
        @Header("Authorization") bearerToken: String,
        @Body body: CheckInOutRequest
    ): CheckInOutResponse

    /**
     * Scan attendance — server exposes POST /api/attendance/scan
     * Body: { token: "<scanned-string>" }
     */
    @POST("/api/attendance/scan")
    suspend fun scanAttendance(
        @Header("Authorization") bearerToken: String,
        @Body body: ScanRequest
    ): ScanResponse
}
