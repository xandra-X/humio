package com.example.hrmanagement.data

data class SimpleResponse(
    val success: Boolean,
    val message: String
)
