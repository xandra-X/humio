package com.example.hrmanagement.data

// Response for check-in / check-out endpoint
data class CheckInOutResponse(
    val ok: Boolean = false,
    val message: String? = null
)
