package com.example.hrmanagement.ui.attendance

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
// Use ZXing integration package provided by the classic integration artifact
import com.google.zxing.integration.android.IntentIntegrator
import com.google.zxing.integration.android.IntentResult

/**
 * Simple scanner wrapper that launches the ZXing capture activity and returns the scanned string.
 * Caller expects returned Intent extra "scan_result" containing the scanned value.
 */
class ScannerActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Configure integrator (integration package is the correct one)
        val integrator = IntentIntegrator(this).apply {
            // QR codes only (using built-in constant)
            setDesiredBarcodeFormats(listOf(IntentIntegrator.QR_CODE))
            setPrompt("Scan QR code from device (press BACK to cancel)")
            setCameraId(0)                 // back camera
            setBeepEnabled(true)
            setBarcodeImageEnabled(false)
            setOrientationLocked(false)
        }
        integrator.initiateScan()
    }

    // receive result from ZXing / journeyapps scanner
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        val result: IntentResult? = IntentIntegrator.parseActivityResult(requestCode, resultCode, data)

        if (result != null) {
            if (result.contents == null) {
                // user cancelled or no result
                setResult(Activity.RESULT_CANCELED)
            } else {
                // success — return scanned string under "scan_result"
                val out = Intent()
                out.putExtra("scan_result", result.contents)
                setResult(Activity.RESULT_OK, out)
            }
            finish()
            return
        }

        super.onActivityResult(requestCode, resultCode, data)
    }
}
