package com.example.hrmanagement.ui.dashboard

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.example.hrmanagement.R
import com.example.hrmanagement.data.CheckInOutRequest
import com.example.hrmanagement.data.DashboardResponse
import com.example.hrmanagement.network.RetrofitClient
import com.example.hrmanagement.ui.attendance.AttendanceActivity
import com.example.hrmanagement.util.SessionManager
import kotlinx.coroutines.launch

class DashboardActivity : AppCompatActivity() {

    private lateinit var sessionManager: SessionManager
    private lateinit var adapter: RecentActivityAdapter

    // views
    private lateinit var imgAvatar: ImageView
    private lateinit var tvEmployeeName: TextView
    private lateinit var tvEmployeeCodeTitle: TextView
    private lateinit var tvTodayTime: TextView
    private lateinit var btnCheckInOut: androidx.appcompat.widget.AppCompatButton

    private lateinit var tvLeaveBalanceDays: TextView
    private lateinit var tvLeaveThisMonthDays: TextView

    // quick access include roots
    private lateinit var itemAttendance: View
    private lateinit var itemLeaveRequests: View
    private lateinit var itemProfile: View
    private lateinit var itemMembers: View

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        sessionManager = SessionManager(this)

        // find views
        imgAvatar = findViewById(R.id.imgAvatar)
        tvEmployeeName = findViewById(R.id.tvEmployeeName)
        tvEmployeeCodeTitle = findViewById(R.id.tvEmployeeCodeTitle)
        tvTodayTime = findViewById(R.id.tvTodayTime)
        btnCheckInOut = findViewById(R.id.btnCheckInOut)

        tvLeaveBalanceDays = findViewById(R.id.tvLeaveBalanceDays)
        tvLeaveThisMonthDays = findViewById(R.id.tvLeaveThisMonthDays)

        itemAttendance = findViewById(R.id.itemAttendance)
        itemLeaveRequests = findViewById(R.id.itemLeaveRequests)
        itemProfile = findViewById(R.id.itemProfile)
        itemMembers = findViewById(R.id.itemMembers)

        val recycler =
            findViewById<androidx.recyclerview.widget.RecyclerView>(R.id.recyclerRecentActivities)
        adapter = RecentActivityAdapter()
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = adapter

        setupQuickAccessCards()

        // IMPORTANT: Do NOT perform check-in/out here.
        // Instead navigate user to AttendanceActivity where the check in/out flow is handled.
        btnCheckInOut.setOnClickListener {
            openAttendanceScreen()
        }

        // quick access click for attendance card
        itemAttendance.setOnClickListener {
            openAttendanceScreen()
        }
    }

    override fun onResume() {
        super.onResume()
        loadDashboard()
    }

    // -------------------------------------------------------------------------
    // OPEN ATTENDANCE SCREEN
    // -------------------------------------------------------------------------
    private fun openAttendanceScreen() {
        val intent = Intent(this, AttendanceActivity::class.java)
        startActivity(intent)
    }

    // -------------------------------------------------------------------------
    // QUICK ACCESS CARDS (with 4 different icons)
    // -------------------------------------------------------------------------
    private fun setupQuickAccessCards() {
        setQuickAccess(
            root = itemAttendance,
            title = "Attendance",
            subtitle = "Check in/out and view history",
            iconRes = R.drawable.usercheck
        )

        setQuickAccess(
            root = itemLeaveRequests,
            title = "Leave Requests",
            subtitle = "Apply and manage leave",
            iconRes = R.drawable.insomnia
        )

        setQuickAccess(
            root = itemProfile,
            title = "Profile",
            subtitle = "View profile and settings",
            iconRes = R.drawable.user
        )

        setQuickAccess(
            root = itemMembers,
            title = "Members",
            subtitle = "Team members & contacts",
            iconRes = R.drawable.usergroups
        )
    }

    private fun setQuickAccess(
        root: View,
        title: String,
        subtitle: String,
        iconRes: Int
    ) {
        val titleView = root.findViewById<TextView>(R.id.tvQuickAccessTitle)
        val subView = root.findViewById<TextView>(R.id.tvQuickAccessSubtitle)
        val iconView = root.findViewById<ImageView>(R.id.ivQuickIcon)

        titleView.text = title
        subView.text = subtitle
        iconView.setImageResource(iconRes)
    }

    // -------------------------------------------------------------------------
    // API CALLS
    // -------------------------------------------------------------------------
    private fun loadDashboard() {
        val token = sessionManager.fetchAuthToken()
        if (token.isNullOrEmpty()) {
            Toast.makeText(this, "No token, please log in again.", Toast.LENGTH_SHORT).show()
            return
        }

        lifecycleScope.launch {
            try {
                val response: DashboardResponse =
                    RetrofitClient.dashboardApi.getDashboard("Bearer $token")
                bindDashboard(response)
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(
                    this@DashboardActivity,
                    "Failed to load dashboard",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    private fun bindDashboard(data: DashboardResponse) {
        // --- Profile text ---
        tvEmployeeName.text = data.employee.fullName
        tvEmployeeCodeTitle.text =
            "${data.employee.employeeCode} · ${data.employee.jobTitle ?: ""}"

        // --- Profile image from Node/web server (port 3000, shared uploads/) ---
        val avatarPath = data.employee.avatarUrl
        if (!avatarPath.isNullOrBlank()) {
            val fullUrl = if (avatarPath.startsWith("http")) {
                avatarPath
            } else {
                // IMPORTANT: Node server for web runs on 3000 and serves /uploads/*
                "http://10.0.2.2:3000$avatarPath"
            }

            Glide.with(this)
                .load(fullUrl)
                .skipMemoryCache(true)
                .diskCacheStrategy(DiskCacheStrategy.NONE)
                .placeholder(R.drawable.ic_launcher_foreground)
                .error(R.drawable.ic_launcher_foreground)
                .circleCrop()
                .into(imgAvatar)
        } else {
            // fallback if no avatar in DB
            imgAvatar.setImageResource(R.drawable.ic_launcher_foreground)
        }

        // --- Today status ---
        tvTodayTime.text = data.todayStatus.checkInTime ?: "Not checked in"

        // keep the button label reflecting status (but the button now navigates)
        btnCheckInOut.text = when {
            data.todayStatus.canCheckIn -> "Check In"
            data.todayStatus.canCheckOut -> "Check Out"
            else -> "Completed"
        }
        btnCheckInOut.isEnabled =
            data.todayStatus.canCheckIn || data.todayStatus.canCheckOut

        // --- Leave summary (logic handled on server) ---
        tvLeaveBalanceDays.text = "${data.leaveSummary.leaveBalanceDays} days"
        tvLeaveThisMonthDays.text = "${data.leaveSummary.usedThisMonthDays} days"

        // --- Recent activities ---
        adapter.submitList(data.recentActivities)
    }

    /**
     * Kept for reuse but not used by dashboard UI anymore.
     * Attendance screen is responsible for performing check in/out.
     */
    private fun handleCheckButton() {
        val token = sessionManager.fetchAuthToken()
        if (token.isNullOrEmpty()) return

        val action = if (btnCheckInOut.text.toString().contains("In", true))
            "CHECK_IN" else "CHECK_OUT"

        lifecycleScope.launch {
            try {
                val result = RetrofitClient.dashboardApi.checkInOut(
                    "Bearer $token",
                    CheckInOutRequest(action)
                )
                Toast.makeText(
                    this@DashboardActivity,
                    result.message,
                    Toast.LENGTH_SHORT
                ).show()
                loadDashboard()
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(
                    this@DashboardActivity,
                    "Failed to update attendance",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }
}
