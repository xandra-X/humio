package com.example.hrmanagement.data

// Response from scan endpoint
data class ScanResponse(
    val ok: Boolean = false,
    val message: String? = null
)
