package com.example.hrmanagement.ui.attendance

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.hrmanagement.data.CheckInOutRequest
import com.example.hrmanagement.data.ScanRequest
import com.example.hrmanagement.data.ScanResponse
import com.example.hrmanagement.data.DashboardResponse
import com.example.hrmanagement.databinding.ActivityAttendanceBinding
import com.example.hrmanagement.network.RetrofitClient
import com.example.hrmanagement.util.SessionManager
import kotlinx.coroutines.launch

class AttendanceActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAttendanceBinding
    private lateinit var session: SessionManager
    private lateinit var adapter: AttendanceRecordAdapter

    // scanner result launcher
    private val scanLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { activityResult ->
        if (activityResult.resultCode == Activity.RESULT_OK) {
            val data = activityResult.data?.getStringExtra("scan_result") ?: return@registerForActivityResult
            // perform server scan
            sendScanToServer(data)
        } else {
            Toast.makeText(this, "Scan cancelled", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAttendanceBinding.inflate(layoutInflater)
        setContentView(binding.root)

        session = SessionManager(this)
        adapter = AttendanceRecordAdapter()
        binding.recyclerRecords.layoutManager = LinearLayoutManager(this)
        binding.recyclerRecords.adapter = adapter

        binding.btnCheck.setOnClickListener { openScanner() }
        binding.btnCheckSecondary.setOnClickListener { openScanner() }
        binding.btnCorrection.setOnClickListener {
            Toast.makeText(this, "Correction page not implemented", Toast.LENGTH_SHORT).show()
        }
        binding.btnBack.setOnClickListener { onBackPressed() }

        loadAttendance()
    }

    private fun openScanner() {
        val it = Intent(this, ScannerActivity::class.java)
        scanLauncher.launch(it)
    }

    private fun sendScanToServer(scannedToken: String) {
        val token = session.fetchAuthToken() ?: run {
            Toast.makeText(this, "No auth", Toast.LENGTH_SHORT).show()
            return
        }
        lifecycleScope.launch {
            try {
                val resp: ScanResponse = RetrofitClient.dashboardApi.scanAttendance("Bearer $token", ScanRequest(scannedToken))
                if (resp.ok) {
                    Toast.makeText(this@AttendanceActivity, resp.message, Toast.LENGTH_SHORT).show()
                    loadAttendance()
                } else {
                    Toast.makeText(this@AttendanceActivity, resp.message, Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(this@AttendanceActivity, "Network error", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun loadAttendance() {
        val token = session.fetchAuthToken() ?: return
        lifecycleScope.launch {
            try {
                val response: DashboardResponse = RetrofitClient.dashboardApi.getDashboard("Bearer $token")
                val s = response.todayStatus
                binding.tvCurrentStatus.text = if (s.checkedIn) "Check In" else "Not Checked In"
                binding.tvTime.text = s.checkInTime ?: "--"
                binding.btnCheck.text = when {
                    s.canCheckIn -> "Check In"
                    s.canCheckOut -> "Check Out"
                    else -> "Completed"
                }
                adapter.submitList(response.recentActivities)
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(this@AttendanceActivity, "Failed to load", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
