package com.example.hrmanagement.network

import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object RetrofitClient {

    // When running server locally and Android emulator uses host machine:
    // - emulator -> use 10.0.2.2
    // If your server uses a different port, change 8080 -> your port
    private const val BASE_URL = "http://10.0.2.2:8080/"

    private val logger = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BODY
    }

    private val client: OkHttpClient = OkHttpClient.Builder()
        .addInterceptor(logger)
        .build()

    private val retrofit: Retrofit by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    // Auth endpoints (login, forgot password, etc.)
    val authApi: AuthApi by lazy {
        retrofit.create(AuthApi::class.java)
    }

    // Dashboard endpoints (home screen data, check-in/out)
    val dashboardApi: DashboardApi by lazy {
        retrofit.create(DashboardApi::class.java)
    }
}
