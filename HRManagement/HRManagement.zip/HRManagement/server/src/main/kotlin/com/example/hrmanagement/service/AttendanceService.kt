package com.example.hrmanagement.service

import com.example.hrmanagement.repo.AttendanceRepository
import com.example.hrmanagement.util.TokenUtils
import com.example.hrmanagement.model.Attendance
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneId

data class ScanResult(val ok: Boolean, val message: String, val action: String? = null)

/**
 * Business logic: verify QR token, enforce 3-minute anti-replay gap (server side),
 * and create check-in or check-out accordingly.
 */
object AttendanceService {

    // simple in-memory last-scan map (userId -> epoch millis). For production use Redis.
    private val lastScan = mutableMapOf<Int, Long>()
    private const val MIN_GAP_SECONDS = 180 // 3 minutes

    fun handleScan(userId: Int, scannedToken: String): ScanResult {
        // verify signed token
        val payload = TokenUtils.verify(scannedToken) ?: return ScanResult(false, "Invalid token")
        // parse payload JSON (very small)
        val ts = try {
            val regex = """.*"ts"\s*:\s*(\d+)""".toRegex()
            val m = regex.find(payload)
            m?.groups?.get(1)?.value?.toLong() ?: return ScanResult(false, "Bad token")
        } catch (e: Exception) {
            return ScanResult(false, "Token parse failed")
        }

        val nowSec = Instant.now().epochSecond
        // accept tokens only if within 60s (token rotating every 20s; allow small skew)
        if (kotlin.math.abs(nowSec - ts) > 90) {
            return ScanResult(false, "Token expired")
        }

        // anti-replay check
        val last = lastScan[userId]
        if (last != null && (Instant.now().toEpochMilli() - last) < MIN_GAP_SECONDS * 1000) {
            return ScanResult(false, "Please wait before scanning again")
        }

        // determine whether to check-in or check-out
        val open = AttendanceRepository.getOpenAttendanceForToday(userId)
        val now = LocalDateTime.now()
        return if (open == null || open.checkIn == null) {
            // create check in
            val id = AttendanceRepository.createCheckIn(userId, now)
            lastScan[userId] = Instant.now().toEpochMilli()
            ScanResult(true, "Checked in", "CHECK_IN")
        } else if (open.checkOut == null) {
            // set checkout
            AttendanceRepository.setCheckOut(open.id, now)
            lastScan[userId] = Instant.now().toEpochMilli()
            ScanResult(true, "Checked out", "CHECK_OUT")
        } else {
            ScanResult(false, "Already completed today")
        }
    }
}
