package com.example.hrmanagement.repo

import com.example.hrmanagement.model.Attendance
import com.example.hrmanagement.model.AttendanceTable
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.transactions.transaction
import java.time.LocalDate
import java.time.LocalDateTime

/**
 * Repository for attendance operations.
 *
 * Important: callers pass the logged-in userId (users table primary key).
 * We resolve employee_id by finding the Employee row with user_id = userId.
 */
object AttendanceRepository {

    private fun resolveEmployeeIdForUser(userId: Int): Int? = transaction {
        EmployeeTable
            .select { EmployeeTable.userId eq userId }
            .singleOrNull()
            ?.get(EmployeeTable.id)
    }

    fun getOpenAttendanceForToday(userId: Int): Attendance? = transaction {
        val employeeId = resolveEmployeeIdForUser(userId) ?: return@transaction null
        val today = LocalDate.now()
        AttendanceTable
            .select { (AttendanceTable.employeeId eq employeeId) and (AttendanceTable.date eq today) }
            .map {
                Attendance(
                    id = it[AttendanceTable.id],
                    employeeId = it[AttendanceTable.employeeId],
                    date = it[AttendanceTable.date],
                    checkIn = it[AttendanceTable.checkIn],
                    checkOut = it[AttendanceTable.checkOut]
                )
            }
            .singleOrNull()
    }

    fun createCheckIn(userId: Int, ts: LocalDateTime): Int = transaction {
        val employeeId = resolveEmployeeIdForUser(userId) ?: error("No employee for userId=$userId")
        val today = ts.toLocalDate()
        val insertStmt = AttendanceTable.insert {
            it[AttendanceTable.employeeId] = employeeId
            it[AttendanceTable.date] = today
            it[AttendanceTable.checkIn] = ts
            it[AttendanceTable.checkOut] = null
            it[AttendanceTable.status] = "PRESENT"
            it[AttendanceTable.sourceType] = "MANUAL"
            it[AttendanceTable.updatedAt] = ts
        }
        insertStmt[AttendanceTable.id]
    }

    fun setCheckOut(attendanceId: Int, ts: LocalDateTime): Boolean = transaction {
        val rows = AttendanceTable.update({ AttendanceTable.id eq attendanceId }) {
            it[AttendanceTable.checkOut] = ts
            it[AttendanceTable.updatedAt] = ts
        }
        rows > 0
    }

    fun createOrUpdateCheckOutForUserToday(userId: Int, ts: LocalDateTime): Boolean = transaction {
        val employeeId = resolveEmployeeIdForUser(userId) ?: return@transaction false
        val today = ts.toLocalDate()
        val exist = AttendanceTable.select { (AttendanceTable.employeeId eq employeeId) and (AttendanceTable.date eq today) }
            .singleOrNull()
        if (exist == null) {
            AttendanceTable.insert {
                it[AttendanceTable.employeeId] = employeeId
                it[AttendanceTable.date] = today
                it[AttendanceTable.checkOut] = ts
                it[AttendanceTable.status] = "PRESENT"
                it[AttendanceTable.sourceType] = "MANUAL"
                it[AttendanceTable.updatedAt] = ts
            }
            true
        } else {
            val id = exist[AttendanceTable.id]
            AttendanceTable.update({ AttendanceTable.id eq id }) {
                it[AttendanceTable.checkOut] = ts
                it[AttendanceTable.updatedAt] = ts
            }
            true
        }
    }

    fun listRecent(userId: Int, limit: Int = 10): List<Attendance> = transaction {
        val employeeId = resolveEmployeeIdForUser(userId) ?: return@transaction emptyList()
        AttendanceTable.select { AttendanceTable.employeeId eq employeeId }
            .orderBy(AttendanceTable.date, SortOrder.DESC)
            .limit(limit)
            .map {
                Attendance(
                    id = it[AttendanceTable.id],
                    employeeId = it[AttendanceTable.employeeId],
                    date = it[AttendanceTable.date],
                    checkIn = it[AttendanceTable.checkIn],
                    checkOut = it[AttendanceTable.checkOut]
                )
            }
    }

    /**
     * Auto-checkout missing check-outs for today.
     */
    fun autoCheckoutAllMissing(checkOutTime: LocalDateTime = LocalDateTime.now().withHour(16).withMinute(30)) = transaction {
        val today = checkOutTime.toLocalDate()
        AttendanceTable.update({
            (AttendanceTable.date eq today) and (AttendanceTable.checkIn.isNotNull()) and (AttendanceTable.checkOut.isNull())
        }) {
            it[AttendanceTable.checkOut] = checkOutTime
            it[AttendanceTable.updatedAt] = checkOutTime
        }
    }
}
