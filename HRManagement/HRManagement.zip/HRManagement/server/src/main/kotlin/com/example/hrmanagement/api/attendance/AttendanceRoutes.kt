package com.example.hrmanagement.api.attendance

import com.example.hrmanagement.service.AttendanceService
import com.example.hrmanagement.repo.UserRepository
import com.example.hrmanagement.model.SimpleResponse
import io.ktor.http.*
import io.ktor.server.application.*
import io.ktor.server.request.*
import io.ktor.server.response.*
import io.ktor.server.routing.*
import com.example.hrmanagement.model.ScanRequest
import com.example.hrmanagement.model.ScanResponse
import com.auth0.jwt.JWT
import com.auth0.jwt.algorithms.Algorithm
import com.example.hrmanagement.util.JwtConfig

fun Application.attendanceRoutes() {
    routing {
        post("/api/attendance/scan") {
            // auth: Authorization: Bearer <token>
            val auth = call.request.headers["Authorization"]
            if (auth.isNullOrBlank() || !auth.startsWith("Bearer ")) {
                call.respond(HttpStatusCode.Unauthorized, SimpleResponse(false, "Missing token"))
                return@post
            }
            val raw = auth.removePrefix("Bearer").trim()
            val email = try {
                JWT
                    .require(Algorithm.HMAC256(JwtConfig.secret))
                    .withIssuer(JwtConfig.issuer)
                    .withAudience(JwtConfig.audience)
                    .build()
                    .verify(raw)
                    .getClaim("email").asString()
            } catch (e: Exception) {
                call.respond(HttpStatusCode.Unauthorized, SimpleResponse(false, "Invalid token"))
                return@post
            }

            val user = UserRepository.findByEmail(email)
            if (user == null) {
                call.respond(HttpStatusCode.Unauthorized, SimpleResponse(false, "User not found"))
                return@post
            }

            val req = call.receive<ScanRequest>()
            val res = AttendanceService.handleScan(user.id, req.token)
            if (res.ok) {
                call.respond(HttpStatusCode.OK, ScanResponse(true, res.message, res.action))
            } else {
                call.respond(HttpStatusCode.BadRequest, ScanResponse(false, res.message, res.action))
            }
        }

        // optional token endpoint left as-is if you use display tokens
        get("/api/attendance/token") {
            val now = java.time.Instant.now().epochSecond
            val payload = """{"ts":$now}"""
            val signed = com.example.hrmanagement.util.TokenUtils.sign(payload)
            call.respond(mapOf("token" to signed))
        }
    }
}
