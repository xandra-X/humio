package com.example.hrmanagement.repo

import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.javatime.datetime
import org.jetbrains.exposed.sql.transactions.transaction
import java.time.LocalDateTime
import java.time.Instant

// Data class used by AuthService
data class PasswordResetToken(
    val id: Int,
    val userId: Int,
    val otpCode: String,
    val expiresAtEpoch: Long,
    val used: Boolean
)

// Table mapping (expects column expires_at_epoch BIGINT)
object PasswordResetTable : Table("password_reset_tokens") {
    val id = integer("id").autoIncrement()
    val userId = integer("user_id")
    val otpCode = varchar("otp_code", 6)
    val expiresAtEpoch = long("expires_at_epoch")     // BIGINT column (epoch seconds)
    val used = bool("used")
    val createdAt = datetime("created_at")

    override val primaryKey = PrimaryKey(id)
}

object PasswordResetRepository {

    /**
     * Store a password reset token with epoch expiry (seconds).
     */
    fun createToken(userId: Int, code: String, expiresAtEpoch: Long) = transaction {
        PasswordResetTable.insert {
            it[PasswordResetTable.userId] = userId
            it[otpCode] = code
            it[PasswordResetTable.expiresAtEpoch] = expiresAtEpoch
            it[used] = false
            it[createdAt] = LocalDateTime.now()
        }
    }

    /**
     * Find a valid (not used & not expired) reset token.
     */
    fun findValidToken(userId: Int, code: String): PasswordResetToken? = transaction {
        val row = PasswordResetTable
            .select {
                (PasswordResetTable.userId eq userId) and
                        (PasswordResetTable.otpCode eq code) and
                        (PasswordResetTable.used eq false)
            }
            .orderBy(PasswordResetTable.createdAt, SortOrder.DESC)
            .limit(1)
            .singleOrNull() ?: return@transaction null

        val expiresEpoch = row[PasswordResetTable.expiresAtEpoch]
        val now = Instant.now().epochSecond

        if (expiresEpoch < now) {
            // expired
            return@transaction null
        }

        PasswordResetToken(
            id = row[PasswordResetTable.id],
            userId = row[PasswordResetTable.userId],
            otpCode = row[PasswordResetTable.otpCode],
            expiresAtEpoch = expiresEpoch,
            used = row[PasswordResetTable.used]
        )
    }

    /**
     * Mark OTP token as used.
     */
    fun markUsed(id: Int) = transaction {
        PasswordResetTable.update({ PasswordResetTable.id eq id }) {
            it[used] = true
        }
    }
}
