package com.example.hrmanagement.api.dashboard

import com.auth0.jwt.JWT
import com.auth0.jwt.algorithms.Algorithm
import com.example.hrmanagement.model.SimpleResponse
import com.example.hrmanagement.model.CheckInOutRequest
import com.example.hrmanagement.service.DashboardService
import com.example.hrmanagement.repo.UserRepository
import com.example.hrmanagement.util.JwtConfig
import io.ktor.http.*
import io.ktor.server.application.*
import io.ktor.server.request.*
import io.ktor.server.response.*
import io.ktor.server.routing.*
import io.ktor.server.auth.*

fun Application.dashboardRoutes(dashboardService: DashboardService) {

    routing {

        // DASHBOARD OVERVIEW (secured by JWT)
        get("/api/dashboard") {
            val userId = extractUserIdFromJwt(call) ?: return@get
            val overview = dashboardService.getDashboard(userId)
            call.respond(overview)
        }

        // CHECK IN / OUT (secured by JWT)
        post("/api/dashboard/check") {
            val userId = extractUserIdFromJwt(call) ?: return@post
            val body = call.receive<CheckInOutRequest>()
            val result = dashboardService.handleCheck(userId, body)
            call.respond(result)
        }
    }
}

/**
 * Read Authorization: Bearer <token>, verify JWT, map to userId.
 */
private suspend fun extractUserIdFromJwt(call: ApplicationCall): Int? {
    val authHeader = call.request.headers["Authorization"]
    if (authHeader.isNullOrBlank() || !authHeader.startsWith("Bearer ")) {
        call.respond(
            HttpStatusCode.Unauthorized,
            SimpleResponse(false, "Missing or invalid Authorization header")
        )
        return null
    }

    val rawToken = authHeader.removePrefix("Bearer").trim()

    val email = try {
        val verifier = JWT
            .require(Algorithm.HMAC256(JwtConfig.secret))
            .withIssuer(JwtConfig.issuer)
            .withAudience(JwtConfig.audience)
            .build()

        val decoded = verifier.verify(rawToken)
        decoded.getClaim("email").asString()
    } catch (e: Exception) {
        call.respond(
            HttpStatusCode.Unauthorized,
            SimpleResponse(false, "Invalid or expired token")
        )
        return null
    }

    val user = UserRepository.findByEmail(email)
    if (user == null) {
        call.respond(
            HttpStatusCode.Unauthorized,
            SimpleResponse(false, "User not found")
        )
        return null
    }

    return user.id
}
