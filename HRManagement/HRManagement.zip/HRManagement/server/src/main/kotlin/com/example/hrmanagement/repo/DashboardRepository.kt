package com.example.hrmanagement.repo

import com.example.hrmanagement.model.*             // bring in the model types: UserTable, SimpleResponse, DTOs
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.javatime.date
import org.jetbrains.exposed.sql.javatime.datetime
import org.jetbrains.exposed.sql.transactions.transaction
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale

// ---- TABLE MAPPINGS for Employee, Leave, OT, Notification (kept here) ----

object EmployeeTable : Table("Employee") {
    val id = integer("employee_id").autoIncrement()
    val employeeCode = varchar("employee_code", 50)
    val jobTitle = varchar("job_title", 150).nullable()
    val userId = integer("user_id").nullable()

    override val primaryKey = PrimaryKey(id)
}

object LeaveRequestTable : Table("LeaveRequest") {
    val id = integer("leave_id").autoIncrement()
    val employeeId = integer("employee_id")
    val leaveType = varchar("leave_type", 20)
    val startDate = date("start_date")
    val endDate = date("end_date")
    val days = decimal("days", 6, 2)
    val status = varchar("status", 20)
    val submittedAt = datetime("submitted_at")
    val updatedAt = datetime("updated_at")

    override val primaryKey = PrimaryKey(id)
}

object OvertimeClaimTable : Table("OvertimeClaim") {
    val id = integer("claim_id").autoIncrement()
    val employeeId = integer("employee_id")
    val date = date("date")
    val hours = decimal("hours", 6, 2)
    val status = varchar("status", 20)
    val updatedAt = datetime("updated_at")

    override val primaryKey = PrimaryKey(id)
}

object NotificationTable : Table("Notification") {
    val id = integer("notification_id").autoIncrement()
    val recipientUserId = integer("recipient_user_id")
    val message = text("message")
    val createdAt = datetime("created_at")

    override val primaryKey = PrimaryKey(id)
}

// Local AttendanceTable for Dashboard queries (this maps to the DB Attendance table)
object AttendanceTable : Table("Attendance") {
    val id = integer("attendance_id").autoIncrement()
    val employeeId = integer("employee_id")
    val date = date("date")
    val checkIn = datetime("check_in").nullable()
    val checkOut = datetime("check_out").nullable()
    val status = varchar("status", 20)              // PRESENT / ABSENT / ...
    val sourceType = varchar("source", 20)          // QR / MANUAL (named sourceType in code to avoid collision)
    val updatedAt = datetime("updated_at")

    override val primaryKey = PrimaryKey(id)
}

// ---- REPOSITORY ----

class DashboardRepository {

    private val timeFormatter = DateTimeFormatter.ofPattern("hh:mm a", Locale.getDefault())

    /**
     * Build the dashboard response for the logged-in user.
     */
    fun getDashboardOverview(userId: Int): DashboardOverview = transaction {
        // 1) User + Employee info
        val userRow = UserTable
            .select { UserTable.id eq userId }
            .singleOrNull() ?: error("User not found for id=$userId")

        val employeeRow = EmployeeTable
            .select { EmployeeTable.userId eq userId }
            .singleOrNull() ?: error("No employee linked to user id=$userId")

        val employeeId = employeeRow[EmployeeTable.id]

        val fullName = userRow[UserTable.fullName] ?: userRow[UserTable.username]
        val employeeCode = employeeRow[EmployeeTable.employeeCode]
        val jobTitle = employeeRow[EmployeeTable.jobTitle]
        val avatarUrl = userRow[UserTable.profileImage]

        val employeeSummary = EmployeeSummary(
            fullName = fullName,
            employeeCode = employeeCode,
            jobTitle = jobTitle,
            avatarUrl = avatarUrl
        )

        // 2) Today's attendance status
        val today = LocalDate.now()

        val attendanceRow = AttendanceTable
            .select { (AttendanceTable.employeeId eq employeeId) and (AttendanceTable.date eq today) }
            .singleOrNull()

        val checkInDt = attendanceRow?.get(AttendanceTable.checkIn)
        val checkOutDt = attendanceRow?.get(AttendanceTable.checkOut)

        val todayStatus = TodayStatus(
            checkedIn = checkInDt != null,
            checkInTime = checkInDt?.format(timeFormatter),
            canCheckIn = attendanceRow == null || checkInDt == null,
            canCheckOut = checkInDt != null && checkOutDt == null
        )

        // 3) Leave summary — 3 leave days per month, show remaining this month
        val ym = YearMonth.from(today)
        val startOfMonth = ym.atDay(1)
        val endOfMonth = ym.atEndOfMonth()

        val monthlyAllowance = 3.0

        val usedThisMonth = LeaveRequestTable
            .select {
                (LeaveRequestTable.employeeId eq employeeId) and
                        (LeaveRequestTable.status eq "APPROVED") and
                        (LeaveRequestTable.startDate greaterEq startOfMonth) and
                        (LeaveRequestTable.startDate lessEq endOfMonth)
            }
            .sumOf { it[LeaveRequestTable.days].toDouble() }

        val remainingThisMonth = (monthlyAllowance - usedThisMonth)
            .coerceAtLeast(0.0)
            .toInt()

        val leaveSummary = LeaveSummary(
            leaveBalanceDays = remainingThisMonth,
            usedThisMonthDays = usedThisMonth.toInt()
        )

        // 4) Recent activities
        val activities = buildRecentActivities(userId, employeeId)

        DashboardOverview(
            employee = employeeSummary,
            todayStatus = todayStatus,
            leaveSummary = leaveSummary,
            recentActivities = activities
        )
    }

    private fun buildRecentActivities(userId: Int, employeeId: Int): List<RecentActivity> = transaction {
        data class A(val at: LocalDateTime, val activity: RecentActivity)

        val items = mutableListOf<A>()

        // Attendance (latest 3)
        AttendanceTable
            .select { AttendanceTable.employeeId eq employeeId }
            .orderBy(AttendanceTable.updatedAt, SortOrder.DESC)
            .limit(3)
            .forEach { row ->
                val checkIn = row[AttendanceTable.checkIn]
                val checkOut = row[AttendanceTable.checkOut]
                val updated = row[AttendanceTable.updatedAt]

                val title = when {
                    checkIn != null && checkOut == null -> "Checked in"
                    checkIn != null && checkOut != null -> "Checked out"
                    else -> "Attendance updated"
                }

                val timeText = checkIn ?: checkOut
                val subtitle = timeText?.let { "At ${it.format(timeFormatter)}" } ?: ""

                items += A(
                    at = updated,
                    activity = RecentActivity(
                        type = "ATTENDANCE",
                        title = title,
                        subtitle = subtitle,
                        createdAt = updated.toString()
                    )
                )
            }

        // Leave requests (latest 3)
        LeaveRequestTable
            .select { LeaveRequestTable.employeeId eq employeeId }
            .orderBy(LeaveRequestTable.updatedAt, SortOrder.DESC)
            .limit(3)
            .forEach { row ->
                val status = row[LeaveRequestTable.status]
                val updated = row[LeaveRequestTable.updatedAt]
                val title = when (status) {
                    "APPROVED" -> "Leave approved"
                    "REJECTED" -> "Leave rejected"
                    else -> "Leave request submitted"
                }

                val subtitle =
                    "${row[LeaveRequestTable.leaveType]} • ${row[LeaveRequestTable.days]} days " +
                            "(${row[LeaveRequestTable.startDate]} - ${row[LeaveRequestTable.endDate]})"

                items += A(
                    at = updated,
                    activity = RecentActivity(
                        type = "LEAVE",
                        title = title,
                        subtitle = subtitle,
                        createdAt = updated.toString()
                    )
                )
            }

        // Overtime claims (latest 3)
        OvertimeClaimTable
            .select { OvertimeClaimTable.employeeId eq employeeId }
            .orderBy(OvertimeClaimTable.updatedAt, SortOrder.DESC)
            .limit(3)
            .forEach { row ->
                val status = row[OvertimeClaimTable.status]
                val updated = row[OvertimeClaimTable.updatedAt]
                val title = when (status) {
                    "APPROVED" -> "Overtime approved"
                    "REJECTED" -> "Overtime rejected"
                    else -> "Overtime claim submitted"
                }

                val subtitle =
                    "Date ${row[OvertimeClaimTable.date]} • ${row[OvertimeClaimTable.hours]} hours"

                items += A(
                    at = updated,
                    activity = RecentActivity(
                        type = "OVERTIME",
                        title = title,
                        subtitle = subtitle,
                        createdAt = updated.toString()
                    )
                )
            }

        // Notifications (latest 3)
        NotificationTable
            .select { NotificationTable.recipientUserId eq userId }
            .orderBy(NotificationTable.createdAt, SortOrder.DESC)
            .limit(3)
            .forEach { row ->
                val created = row[NotificationTable.createdAt]
                val message = row[NotificationTable.message]

                items += A(
                    at = created,
                    activity = RecentActivity(
                        type = "NOTIFICATION",
                        title = "Notification",
                        subtitle = message.take(80),
                        createdAt = created.toString()
                    )
                )
            }

        items
            .sortedByDescending { it.at }
            .map { it.activity }
            .take(10)
    }

    /**
     * Handle CHECK_IN / CHECK_OUT and persist to Attendance.
     */
    fun handleCheck(userId: Int, action: String): SimpleResponse = transaction {
        val employeeRow = EmployeeTable
            .select { EmployeeTable.userId eq userId }
            .singleOrNull()
            ?: return@transaction SimpleResponse(false, "No employee profile linked to this user")

        val employeeId = employeeRow[EmployeeTable.id]
        val today = LocalDate.now()

        when (action.uppercase()) {
            "CHECK_IN" -> {
                val existing = AttendanceTable
                    .select { (AttendanceTable.employeeId eq employeeId) and (AttendanceTable.date eq today) }
                    .singleOrNull()

                val now = LocalDateTime.now()

                if (existing != null && existing[AttendanceTable.checkIn] != null) {
                    SimpleResponse(false, "Already checked in for today")
                } else if (existing != null) {
                    AttendanceTable.update({ AttendanceTable.id eq existing[AttendanceTable.id] }) {
                        it[AttendanceTable.checkIn] = now
                        it[AttendanceTable.status] = "PRESENT"
                        it[AttendanceTable.sourceType] = "MANUAL"
                        it[AttendanceTable.updatedAt] = now
                    }
                    SimpleResponse(true, "Checked in successfully")
                } else {
                    AttendanceTable.insert {
                        it[AttendanceTable.employeeId] = employeeId
                        it[AttendanceTable.date] = today
                        it[AttendanceTable.checkIn] = now
                        it[AttendanceTable.checkOut] = null
                        it[AttendanceTable.status] = "PRESENT"
                        it[AttendanceTable.sourceType] = "MANUAL"
                        it[AttendanceTable.updatedAt] = now
                    }
                    SimpleResponse(true, "Checked in successfully")
                }
            }

            "CHECK_OUT" -> {
                val existing = AttendanceTable
                    .select { (AttendanceTable.employeeId eq employeeId) and (AttendanceTable.date eq today) }
                    .singleOrNull()
                    ?: return@transaction SimpleResponse(false, "No check-in found for today")

                val now = LocalDateTime.now()

                if (existing[AttendanceTable.checkOut] != null) {
                    SimpleResponse(false, "Already checked out for today")
                } else if (existing[AttendanceTable.checkIn] == null) {
                    SimpleResponse(false, "Cannot check-out before check-in")
                } else {
                    AttendanceTable.update({ AttendanceTable.id eq existing[AttendanceTable.id] }) {
                        it[AttendanceTable.checkOut] = now
                        it[AttendanceTable.updatedAt] = now
                    }
                    SimpleResponse(true, "Checked out successfully")
                }
            }

            else -> SimpleResponse(false, "Unknown action: $action")
        }
    }
}
