package com.example.hrmanagement.util

import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec
import java.util.Base64
import java.nio.charset.StandardCharsets
import java.time.Instant

object TokenUtils {
    private val secret = System.getenv("QR_TOKEN_SECRET") ?: "dev-secret-change-me"

    // format: base64(payload) + "." + base64(hmac)
    fun sign(payload: String): String {
        val b = payload.toByteArray(StandardCharsets.UTF_8)
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(secret.toByteArray(StandardCharsets.UTF_8), "HmacSHA256"))
        val sig = mac.doFinal(b)
        return Base64.getUrlEncoder().withoutPadding().encodeToString(b) + "." +
                Base64.getUrlEncoder().withoutPadding().encodeToString(sig)
    }

    fun verify(token: String): String? {
        val parts = token.split(".")
        if (parts.size != 2) return null
        try {
            val payload = String(Base64.getUrlDecoder().decode(parts[0]), StandardCharsets.UTF_8)
            val sig = Base64.getUrlDecoder().decode(parts[1])
            val mac = Mac.getInstance("HmacSHA256")
            mac.init(SecretKeySpec(secret.toByteArray(StandardCharsets.UTF_8), "HmacSHA256"))
            val expected = mac.doFinal(payload.toByteArray(StandardCharsets.UTF_8))
            if (!expected.contentEquals(sig)) return null
            return payload
        } catch (e: Exception) {
            return null
        }
    }
}
