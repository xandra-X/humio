package com.example.hrmanagement

import com.example.hrmanagement.api.auth.authRoutes
import com.example.hrmanagement.api.dashboard.dashboardRoutes
import com.example.hrmanagement.api.attendance.attendanceRoutes
import com.example.hrmanagement.config.DatabaseConfig
import com.example.hrmanagement.repo.DashboardRepository
import com.example.hrmanagement.service.DashboardService
import com.example.hrmanagement.util.JwtConfig
import com.example.hrmanagement.util.MailConfig
import com.typesafe.config.ConfigFactory
import io.ktor.serialization.kotlinx.json.*
import io.ktor.server.application.*
import io.ktor.server.engine.*
import io.ktor.server.netty.*
import io.ktor.server.plugins.contentnegotiation.*
import io.ktor.server.routing.*
import io.ktor.server.http.content.*
import io.ktor.server.response.*
import kotlinx.coroutines.*
import java.time.Duration
import java.time.ZonedDateTime

fun main() {
    // Load configuration (e.g., from application.conf)
    val config = ConfigFactory.load()
    val port = config.getInt("ktor.deployment.port")

    // Initialize database + JWT + Mail settings
    DatabaseConfig.init()
    JwtConfig.init()
    MailConfig.init()

    // IMPORTANT: bind to 0.0.0.0 so emulator / other devices can reach the server
    embeddedServer(
        Netty,
        host = "0.0.0.0",
        port = port
    ) {
        // JSON (Kotlinx) for request/response bodies
        install(ContentNegotiation) {
            json()
        }

        // Dashboard repo + service
        val dashboardRepo = DashboardRepository()
        val dashboardService = DashboardService(dashboardRepo)

        // Register routing and APIs
        authRoutes()
        dashboardRoutes(dashboardService)
        attendanceRoutes()

        // add a tiny health endpoint so emulator/device can test connectivity quickly
        routing {
            get("/health") {
                call.respondText("OK")
            }

            // static file serving for uploads
            static("/uploads") {
                files("uploads")
            }
        }

        // schedule auto-checkout coroutine
        scheduleAutoCheckout()
    }.start(wait = true)

    println("Ktor server started and listening on 0.0.0.0:$port")
}

/**
 * Simple coroutine scheduler: sleeps until next 16:30 local time, then runs auto-checkout.
 * Uses the AttendanceRepository.autoCheckoutAllMissing that must exist.
 */
private fun Application.scheduleAutoCheckout() {
    val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    scope.launch {
        while (isActive) {
            try {
                val now = ZonedDateTime.now()
                val today430 = now.withHour(16).withMinute(30).withSecond(0).withNano(0)
                val next = if (now <= today430) today430 else today430.plusDays(1)
                val delayMs = Duration.between(ZonedDateTime.now(), next).toMillis()
                if (delayMs > 0) delay(delayMs)

                // call repository auto-checkout (ensure AttendanceRepository.autoCheckoutAllMissing exists)
                try {
                    com.example.hrmanagement.repo.AttendanceRepository.autoCheckoutAllMissing(next.toLocalDateTime())
                    println("Auto-checkout executed at $next")
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            } catch (e: CancellationException) {
                // shutdown
                break
            } catch (e: Exception) {
                e.printStackTrace()
                // short sleep to avoid busy loop on errors
                delay(10_000)
            }
        }
    }
}
