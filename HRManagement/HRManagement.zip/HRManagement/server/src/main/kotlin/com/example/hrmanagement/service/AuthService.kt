package com.example.hrmanagement.service

import com.example.hrmanagement.model.*
import com.example.hrmanagement.repo.UserRepository
import com.example.hrmanagement.repo.PasswordResetRepository
import com.example.hrmanagement.util.JwtTokenGenerator
import org.mindrot.jbcrypt.BCrypt
import java.security.SecureRandom
import java.time.Instant

object AuthService {

    // ============================================================
    // LOGIN
    // ============================================================
    fun login(request: LoginRequest): LoginResponse {
        val user = UserRepository.findByEmail(request.email)
            ?: return LoginResponse(false, "Invalid email")

        if (!BCrypt.checkpw(request.password, user.passwordHash)) {
            return LoginResponse(false, "Invalid password")
        }

        val token = JwtTokenGenerator.createToken(user.email)
        return LoginResponse(true, "Login successful", token)
    }

    // ============================================================
    // FORGOT PASSWORD — GENERATE OTP
    // ============================================================
    fun requestPasswordReset(email: String): SimpleResponse {
        val user = UserRepository.findByEmail(email)
        if (user == null) {
            // for security you could return success to avoid enumeration; here we'll return not found
            return SimpleResponse(false, "No account found with that email")
        }

        val otp = generateOtp()
        val expiresEpoch = Instant.now().epochSecond + 10 * 60L // 10 minutes from now

        PasswordResetRepository.createToken(user.id, otp, expiresEpoch)

        val sent = EmailService.sendResetCode(email, otp)
        return if (sent) {
            SimpleResponse(true, "Verification code sent to $email")
        } else {
            SimpleResponse(false, "Failed to send verification email")
        }
    }

    // ============================================================
    // VERIFY OTP
    // ============================================================
    fun verifyResetCode(email: String, code: String): SimpleResponse {
        val user = UserRepository.findByEmail(email)
            ?: return SimpleResponse(false, "Invalid email or code")

        val token = PasswordResetRepository.findValidToken(user.id, code)

        return if (token == null) {
            SimpleResponse(false, "Invalid or expired code")
        } else {
            SimpleResponse(true, "Code verified")
        }
    }

    // ============================================================
    // RESET PASSWORD
    // ============================================================
    fun resetPassword(email: String, code: String, newPassword: String): SimpleResponse {
        val user = UserRepository.findByEmail(email)
            ?: return SimpleResponse(false, "Invalid email or code")

        val token = PasswordResetRepository.findValidToken(user.id, code)
            ?: return SimpleResponse(false, "Invalid or expired code")

        val newHash = BCrypt.hashpw(newPassword, BCrypt.gensalt())

        val updated = UserRepository.updatePassword(user.id, newHash)
        if (!updated) {
            return SimpleResponse(false, "Failed to update password")
        }

        PasswordResetRepository.markUsed(token.id)

        return SimpleResponse(true, "Password updated successfully")
    }

    // ============================================================
    // HELPER: Generate 6-digit OTP
    // ============================================================
    private fun generateOtp(): String {
        val random = SecureRandom()
        val number = random.nextInt(1_000_000)
        return String.format("%06d", number)
    }
}
