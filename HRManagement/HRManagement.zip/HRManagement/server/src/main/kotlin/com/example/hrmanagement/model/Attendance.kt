package com.example.hrmanagement.model

import org.jetbrains.exposed.sql.Table
import org.jetbrains.exposed.sql.javatime.date
import org.jetbrains.exposed.sql.javatime.datetime
import java.time.LocalDate
import java.time.LocalDateTime

/**
 * Exposed mapping for the DB table named exactly "Attendance"
 * Columns match the MySQL dump:
 *  - attendance_id (PK)
 *  - employee_id
 *  - date
 *  - check_in
 *  - check_out
 *  - status
 *  - source
 *  - updated_at
 *
 * Note: we name the Kotlin property `sourceType` to avoid colliding with Exposed's ColumnSet.source
 * while mapping to the DB column named `source`.
 */
object AttendanceTable : Table("Attendance") {
    val id = integer("attendance_id").autoIncrement()
    val employeeId = integer("employee_id")           // matches DB
    val date = date("date")
    val checkIn = datetime("check_in").nullable()     // matches DB column check_in
    val checkOut = datetime("check_out").nullable()   // matches DB column check_out
    val status = varchar("status", 20).default("PRESENT")
    val sourceType = varchar("source", 20).default("QR") // column name `source` in DB, property `sourceType` in code
    val updatedAt = datetime("updated_at")

    override val primaryKey = PrimaryKey(id)
}

/**
 * Data class used in application code
 */
data class Attendance(
    val id: Int,
    val employeeId: Int,
    val date: LocalDate,
    val checkIn: LocalDateTime?,
    val checkOut: LocalDateTime?
)
