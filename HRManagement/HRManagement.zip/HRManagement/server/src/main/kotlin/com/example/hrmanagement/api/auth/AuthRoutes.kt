package com.example.hrmanagement.api.auth

import com.example.hrmanagement.data.*
import com.example.hrmanagement.service.AuthService
import io.ktor.http.*
import io.ktor.server.application.*
import io.ktor.server.request.*
import io.ktor.server.response.*
import io.ktor.server.routing.*

fun Application.authRoutes() {
    routing {
        post("/api/auth/login") {
            val request = call.receive<LoginRequest>()
            val response = AuthService.login(request)
            // always 200 for login JSON (body contains success flag)
            call.respond(response)
        }

        post("/api/auth/forgot-password") {
            val request = call.receive<ForgotPasswordRequest>()
            val result = AuthService.requestPasswordReset(request.email)
            val status = if (result.success) HttpStatusCode.OK else HttpStatusCode.BadRequest
            call.respond(status, result)
        }

        post("/api/auth/verify-reset-code") {
            val request = call.receive<VerifyResetCodeRequest>()
            val result = AuthService.verifyResetCode(request.email, request.code)
            val status = if (result.success) HttpStatusCode.OK else HttpStatusCode.BadRequest
            call.respond(status, result)
        }

        post("/api/auth/reset-password") {
            val request = call.receive<ResetPasswordRequest>()
            val result = AuthService.resetPassword(request.email, request.code, request.newPassword)
            val status = if (result.success) HttpStatusCode.OK else HttpStatusCode.BadRequest
            call.respond(status, result)
        }
    }
}
