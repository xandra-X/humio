package com.example.hrmanagement.repo

import com.example.hrmanagement.model.User
import com.example.hrmanagement.model.UserTable
import org.jetbrains.exposed.sql.select
import org.jetbrains.exposed.sql.update
import org.jetbrains.exposed.sql.transactions.transaction

object UserRepository {

    /**
     * Find a user by email.
     * Returns a User data class or null if not found.
     */
    fun findByEmail(email: String): User? = transaction {
        UserTable
            .select { UserTable.email eq email }
            .singleOrNull()
            ?.let { row ->
                User(
                    id = row[UserTable.id],
                    username = row[UserTable.username],
                    email = row[UserTable.email],
                    passwordHash = row[UserTable.passwordHash],
                    fullName = row[UserTable.fullName],
                    profileImage = row[UserTable.profileImage],
                    userType = row[UserTable.userType],
                    createdAt = row[UserTable.createdAt],
                    lastLogin = row[UserTable.lastLogin],
                    updatedAt = row[UserTable.updatedAt]
                )
            }
    }

    /**
     * Update a user's password hash.
     */
    fun updatePassword(userId: Int, newHash: String): Boolean = transaction {
        val rows = UserTable.update({ UserTable.id eq userId }) {
            it[passwordHash] = newHash
        }
        rows > 0
    }
}
