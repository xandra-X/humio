package com.example.hrmanagement.model

import org.jetbrains.exposed.sql.Table
import org.jetbrains.exposed.sql.javatime.datetime
import java.time.LocalDateTime

/**
 * Data class representing a user (server-side).
 * Fields mirror the DB dump's `User` table.
 */
data class User(
    val id: Int,
    val username: String,
    val email: String,
    val passwordHash: String,
    val fullName: String?,
    val profileImage: String?,
    val userType: String,
    val createdAt: LocalDateTime,
    val lastLogin: LocalDateTime?,
    val updatedAt: LocalDateTime?
)

/**
 * Exposed mapping for the DB table named exactly "User" (capital U) — this matches your SQL dump.
 * IMPORTANT: Table name must match the real DB table name.
 */
object UserTable : Table(name = "User") {
    val id = integer("user_id").autoIncrement()
    val username = varchar("username", 100)
    val passwordHash = varchar("password_hash", 255)
    val email = varchar("email", 255)
    val fullName = varchar("full_name", 255).nullable()
    val profileImage = varchar("profile_image", 500).nullable()
    val userType = varchar("user_type", 30).default("EMPLOYEE")
    val createdAt = datetime("created_at").clientDefault { LocalDateTime.now() }
    val lastLogin = datetime("last_login").nullable()
    val updatedAt = datetime("updated_at").clientDefault { LocalDateTime.now() }

    override val primaryKey = PrimaryKey(id, name = "pk_user_id")
}
