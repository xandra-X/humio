package com.example.hrmanagement.service

import java.util.Properties
import jakarta.mail.Message
import jakarta.mail.PasswordAuthentication
import jakarta.mail.Session
import jakarta.mail.Transport
import jakarta.mail.internet.InternetAddress
import jakarta.mail.internet.MimeMessage
import com.example.hrmanagement.util.MailConfig

object EmailService {

    /**
     * For dev: print OTP to server log and return true.
     * Replace implementation with real SMTP as needed (MailConfig holds settings).
     */
    fun sendResetCode(email: String, code: String): Boolean {
        try {
            // Log for development
            println(">>> [EMAIL] sendResetCode to=$email code=$code")

            // If MailConfig is configured and you want to actually send, uncomment and use below.
            /*
            val props = Properties().apply {
                put("mail.smtp.auth", "true")
                put("mail.smtp.starttls.enable", "true")
                put("mail.smtp.host", MailConfig.host)
                put("mail.smtp.port", MailConfig.port.toString())
                put("mail.smtp.ssl.trust", MailConfig.host)
            }

            val session = Session.getInstance(props, object : jakarta.mail.Authenticator() {
                override fun getPasswordAuthentication(): PasswordAuthentication {
                    return PasswordAuthentication(MailConfig.username, MailConfig.password)
                }
            })

            val message = MimeMessage(session).apply {
                setFrom(InternetAddress(MailConfig.username))
                setRecipients(Message.RecipientType.TO, InternetAddress.parse(email, false))
                subject = "Your reset code"
                setText("Your code is: $code\n\nThis code expires in 10 minutes.")
            }
            Transport.send(message)
            println(">>> [EMAIL] actual SMTP send OK")
            */

            return true
        } catch (e: Exception) {
            println(">>> [EMAIL ERROR] ${e.message}")
            e.printStackTrace()
            return false
        }
    }
}
