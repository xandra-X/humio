package com.example.hrmanagement.util

import com.auth0.jwt.JWT
import com.auth0.jwt.algorithms.Algorithm
import java.util.Date

object JwtTokenGenerator {

    fun createToken(email: String): String {
        val config = com.typesafe.config.ConfigFactory.load().getConfig("ktor.jwt")
        val secret = config.getString("secret")
        val issuer = config.getString("issuer")
        val audience = config.getString("audience")

        val algorithm = Algorithm.HMAC256(secret)

        return JWT.create()
            .withIssuer(issuer)
            .withAudience(audience)
            .withClaim("email", email)
            .withExpiresAt(Date(System.currentTimeMillis() + 7L * 24 * 60 * 60 * 1000)) // 7 days
            .sign(algorithm)
    }
}
