package com.example.hrmanagement.api.dashboard

import com.example.hrmanagement.model.CheckInOutRequest
import com.example.hrmanagement.service.DashboardService
import io.ktor.server.application.*
import io.ktor.server.request.*
import io.ktor.server.response.*
import io.ktor.server.routing.*
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonObject
import java.util.Base64

fun Application.dashboardRoutes(dashboardService: DashboardService) {

    routing {
        // GET /api/dashboard
        get("/api/dashboard") {
            val userId = resolveUserId(call)
            val overview = dashboardService.getDashboard(userId)
            call.respond(overview)
        }

        // POST /api/dashboard/check
        post("/api/dashboard/check") {
            val userId = resolveUserId(call)
            val body = call.receive<CheckInOutRequest>()
            val result = dashboardService.handleCheck(userId, body)
            call.respond(result)
        }
    }
}

/**
 * Resolve user id from the request by checking:
 *  1) X-User-Id header
 *  2) userId query parameter
 *  3) Authorization: Bearer <jwt> (try to parse payload JSON for common id claims)
 *  4) fallback to 1
 */
private fun resolveUserId(call: ApplicationCall): Int {
    // 1) header
    val headerUserId = call.request.header("X-User-Id")?.toIntOrNull()
    if (headerUserId != null) return headerUserId

    // 2) query parameter
    val qpUserId = call.request.queryParameters["userId"]?.toIntOrNull()
    if (qpUserId != null) return qpUserId

    // 3) try to parse JWT from Authorization header (naive base64 decode of payload)
    val auth = call.request.header("Authorization")?.let { it.removePrefix("Bearer").trim() }
    if (!auth.isNullOrBlank()) {
        try {
            val parts = auth.split(".")
            if (parts.size >= 2) {
                val payloadB64 = parts[1]
                // JWT payload is base64url encoded — use URL decoder
                val decoded = String(Base64.getUrlDecoder().decode(payloadB64))
                val elem = Json.parseToJsonElement(decoded).jsonObject

                // Try a few candidate claim names
                val candidateKeys = listOf("userId", "user_id", "id", "sub")
                for (k in candidateKeys) {
                    val v = elem[k]
                    if (v != null) {
                        try {
                            val s = v.toString().trim().trim('"')
                            val asInt = s.toIntOrNull()
                            if (asInt != null) return asInt
                        } catch (_: Exception) {
                        }
                    }
                }
            }
        } catch (e: Exception) {
            // use call.application.environment.log to avoid unresolved reference
            call.application.environment.log.debug("Could not parse JWT for user id: ${e.message}")
        }
    }

    // 4) fallback
    return 1
}
