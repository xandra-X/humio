package com.example.hrmanagement

import com.example.hrmanagement.api.auth.authRoutes
import com.example.hrmanagement.api.dashboard.dashboardRoutes
import com.example.hrmanagement.config.DatabaseConfig
import com.example.hrmanagement.repo.DashboardRepository
import com.example.hrmanagement.service.DashboardService
import com.example.hrmanagement.util.JwtConfig
import com.example.hrmanagement.util.MailConfig
import com.typesafe.config.ConfigFactory
import io.ktor.serialization.kotlinx.json.*
import io.ktor.server.application.*
import io.ktor.server.engine.*
import io.ktor.server.netty.*
import io.ktor.server.plugins.contentnegotiation.*
import io.ktor.server.routing.*
import io.ktor.server.http.content.*
import java.io.File

fun main() {
    // Load configuration (e.g., from application.conf)
    val config = ConfigFactory.load()
    val port = config.getInt("ktor.deployment.port")

    // Initialize database + JWT + Mail settings
    DatabaseConfig.init()
    JwtConfig.init()
    MailConfig.init()

    embeddedServer(Netty, port = port) {
        // JSON (Kotlinx) for request/response bodies
        install(ContentNegotiation) {
            json()
        }

        // Serve uploads folder as static files at /uploads
        val uploadsPath = ConfigFactory.load().getString("app.uploadsPath")
        routing {
            // note: `static`/`files` may show deprecation warnings depending on Ktor version,
            // but they still compile. We keep this simple for now.
            static("/uploads") {
                staticRootFolder = File(uploadsPath)
                files(".")
                default("index.html")
            }
        }

        // Dashboard repo + service (currently using stub/demo data)
        val dashboardRepo = DashboardRepository()
        val dashboardService = DashboardService(dashboardRepo)

        // Routes
        authRoutes()
        dashboardRoutes(dashboardService)
    }.start(wait = true)
}
