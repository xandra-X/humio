package com.example.hrmanagement.repo

import com.example.hrmanagement.model.*
import com.typesafe.config.ConfigFactory
import java.time.LocalDate

class DashboardRepository {

    /**
     * Return dashboard overview populated from DB (User table) when possible.
     * NOTE: avatarUrl returned is intentionally a relative/absolute path:
     *  - If DB value is a full http(s) URL -> return as-is
     *  - If DB value starts with '/' -> return as-is (e.g. "/uploads/..")
     *  - If DB value is just a filename -> return "/uploads/profile_images/<filename>"
     *
     * Returning a relative path avoids emulator <-> host `localhost` mismatch.
     */
    fun getDashboardOverview(userId: Int): DashboardOverview {
        val today = LocalDate.now()

        // fetch user from DB (returns null if not found)
        val user = UserRepository.findById(userId)

        // profileImageFromDb may be null, filename, absolute path (starting with '/'), or full URL
        val profileImageFromDb = user?.profileImage

        val avatarUrl = profileImageFromDb?.let { raw ->
            when {
                raw.isBlank() -> null
                raw.startsWith("http", ignoreCase = true) -> raw                // already a full URL
                raw.startsWith("/") -> raw                                     // absolute path on server: /uploads/...
                else -> "/uploads/profile_images/$raw"                          // just a filename -> build relative path
            }
        }

        val employee = if (user != null) {
            EmployeeSummary(
                fullName = user.fullName ?: user.username,
                employeeCode = user.username.ifBlank { user.id.toString() }, // fallback if no username
                jobTitle = user.userType ?: "",
                avatarUrl = avatarUrl
            )
        } else {
            // fallback demo data if user not found
            EmployeeSummary(
                fullName = "Demo User",
                employeeCode = "EMP001",
                jobTitle = "UI/UX Designer",
                avatarUrl = avatarUrl
            )
        }

        val status = TodayStatus(
            checkedIn = true,
            checkInTime = "09:00 AM",
            canCheckIn = false,
            canCheckOut = true
        )

        val leaveSummary = LeaveSummary(
            leaveBalanceDays = 12,
            usedThisMonthDays = 2
        )

        val recent = listOf(
            RecentActivity(
                type = "ATTENDANCE",
                title = "Checked in successfully",
                subtitle = "Today at 09:00 AM",
                createdAt = today.toString()
            ),
            RecentActivity(
                type = "LEAVE",
                title = "Leave request approved",
                subtitle = "2 days ago",
                createdAt = today.minusDays(2).toString()
            )
        )

        return DashboardOverview(
            employee = employee,
            todayStatus = status,
            leaveSummary = leaveSummary,
            recentActivities = recent
        )
    }

    /**
     * Handle a check-in / check-out request.
     * Currently stubbed; hook into Attendance table later.
     */
    fun handleCheck(userId: Int, action: String): SimpleResponse {
        return when (action) {
            "CHECK_IN" ->
                SimpleResponse(success = true, message = "Checked in successfully")
            "CHECK_OUT" ->
                SimpleResponse(success = true, message = "Checked out successfully")
            else ->
                SimpleResponse(success = false, message = "Unknown action")
        }
    }
}
