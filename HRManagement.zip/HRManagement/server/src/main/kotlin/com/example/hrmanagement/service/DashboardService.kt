package com.example.hrmanagement.service

import com.example.hrmanagement.model.CheckInOutRequest
import com.example.hrmanagement.model.DashboardOverview
import com.example.hrmanagement.model.SimpleResponse
import com.example.hrmanagement.repo.DashboardRepository

class DashboardService(
    private val repo: DashboardRepository
) {

    fun getDashboard(userId: Int): DashboardOverview {
        return repo.getDashboardOverview(userId)
    }

    fun handleCheck(userId: Int, request: CheckInOutRequest): SimpleResponse {
        return repo.handleCheck(userId, request.action)
    }
}
