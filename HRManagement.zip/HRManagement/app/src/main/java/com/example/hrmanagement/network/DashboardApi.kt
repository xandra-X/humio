package com.example.hrmanagement.network

import com.example.hrmanagement.data.CheckInOutRequest
import com.example.hrmanagement.data.DashboardResponse
import com.example.hrmanagement.data.SimpleResponse
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST

interface DashboardApi {

    @GET("/api/dashboard")
    suspend fun getDashboard(
        @Header("Authorization") bearerToken: String,
        @Header("X-User-Id") userId: String? = null
    ): Response<DashboardResponse>

    @POST("/api/dashboard/check")
    suspend fun checkInOut(
        @Header("Authorization") bearerToken: String,
        @Header("X-User-Id") userId: String? = null,
        @Body body: CheckInOutRequest
    ): Response<SimpleResponse>
}
