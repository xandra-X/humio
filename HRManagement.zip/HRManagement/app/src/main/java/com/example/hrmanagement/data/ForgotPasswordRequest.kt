package com.example.hrmanagement.data

data class ForgotPasswordRequest(
    val email: String
)
