package com.example.hrmanagement.data

data class LoginRequest(
    val email: String,
    val password: String
)
