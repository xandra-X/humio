package com.example.hrmanagement.ui.dashboard

import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.example.hrmanagement.R
import com.example.hrmanagement.data.CheckInOutRequest
import com.example.hrmanagement.data.DashboardResponse
import com.example.hrmanagement.data.SimpleResponse
import com.example.hrmanagement.network.RetrofitClient
import com.example.hrmanagement.util.SessionManager
import kotlinx.coroutines.launch
import retrofit2.Response

class DashboardActivity : AppCompatActivity() {

    private lateinit var sessionManager: SessionManager
    private lateinit var adapter: RecentActivityAdapter

    // views
    private lateinit var imgAvatar: ImageView
    private lateinit var tvEmployeeName: TextView
    private lateinit var tvEmployeeCodeTitle: TextView
    private lateinit var tvTodayTime: TextView
    private lateinit var btnCheckInOut: androidx.appcompat.widget.AppCompatButton

    private lateinit var tvLeaveBalanceDays: TextView
    private lateinit var tvLeaveThisMonthDays: TextView

    // quick access include roots
    private lateinit var itemAttendance: View
    private lateinit var itemLeaveRequests: View
    private lateinit var itemProfile: View
    private lateinit var itemMembers: View

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        sessionManager = SessionManager(this)

        // find views
        imgAvatar = findViewById(R.id.imgAvatar)
        tvEmployeeName = findViewById(R.id.tvEmployeeName)
        tvEmployeeCodeTitle = findViewById(R.id.tvEmployeeCodeTitle)
        tvTodayTime = findViewById(R.id.tvTodayTime)
        btnCheckInOut = findViewById(R.id.btnCheckInOut)

        tvLeaveBalanceDays = findViewById(R.id.tvLeaveBalanceDays)
        tvLeaveThisMonthDays = findViewById(R.id.tvLeaveThisMonthDays)

        itemAttendance = findViewById(R.id.itemAttendance)
        itemLeaveRequests = findViewById(R.id.itemLeaveRequests)
        itemProfile = findViewById(R.id.itemProfile)
        itemMembers = findViewById(R.id.itemMembers)

        val recycler =
            findViewById<androidx.recyclerview.widget.RecyclerView>(R.id.recyclerRecentActivities)
        adapter = RecentActivityAdapter()
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = adapter

        setupQuickAccessCards()

        btnCheckInOut.setOnClickListener {
            handleCheckButton()
        }
    }

    override fun onResume() {
        super.onResume()
        loadDashboard()
    }

    // -------------------------------------------------------------------------
    // QUICK ACCESS CARDS (with 4 different icons)
    // -------------------------------------------------------------------------
    private fun setupQuickAccessCards() {
        setQuickAccess(
            root = itemAttendance,
            title = "Attendance",
            subtitle = "Check in/out and view history",
            iconRes = R.drawable.usercheck
        )

        setQuickAccess(
            root = itemLeaveRequests,
            title = "Leave Requests",
            subtitle = "Apply and manage leave",
            iconRes = R.drawable.insomnia
        )

        setQuickAccess(
            root = itemProfile,
            title = "Profile",
            subtitle = "View profile and settings",
            iconRes = R.drawable.user
        )

        setQuickAccess(
            root = itemMembers,
            title = "Members",
            subtitle = "Team members & contacts",
            iconRes = R.drawable.usergroups
        )
    }

    private fun setQuickAccess(
        root: View,
        title: String,
        subtitle: String,
        iconRes: Int
    ) {
        val titleView = root.findViewById<TextView>(R.id.tvQuickAccessTitle)
        val subView = root.findViewById<TextView>(R.id.tvQuickAccessSubtitle)
        val iconView = root.findViewById<ImageView>(R.id.ivQuickIcon)

        titleView.text = title
        subView.text = subtitle
        iconView.setImageResource(iconRes)
    }

    // -------------------------------------------------------------------------
    // API CALLS
    // -------------------------------------------------------------------------
    private fun loadDashboard() {
        val token = sessionManager.fetchAuthToken()
        if (token.isNullOrEmpty()) {
            Toast.makeText(this, "No token, please log in again.", Toast.LENGTH_SHORT).show()
            return
        }

        // fetch optional user id header (stored in session manager)
        val userIdHeader = sessionManager.fetchUserId()?.toString()

        lifecycleScope.launch {
            try {
                val resp: Response<DashboardResponse> =
                    RetrofitClient.dashboardApi.getDashboard("Bearer $token", userIdHeader)

                // Debug logs / toast to help troubleshoot
                val code = resp.code()
                val msg = resp.message()
                val rawError = try { resp.errorBody()?.string() } catch (e: Exception) { null }
                android.util.Log.d("DBG_DASH", "GET /api/dashboard code=$code message=$msg errorBody=$rawError")
                Toast.makeText(this@DashboardActivity, "Dashboard HTTP $code", Toast.LENGTH_SHORT).show()

                if (resp.isSuccessful) {
                    val body = resp.body()
                    if (body != null) {
                        android.util.Log.d("DBG_DASH", "Dashboard body: employee=${body.employee}")
                        bindDashboard(body)
                    } else {
                        android.util.Log.e("DBG_DASH", "body() was null despite isSuccessful")
                        Toast.makeText(this@DashboardActivity, "Empty dashboard body", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    android.util.Log.e("DBG_DASH", "Dashboard failed: code=$code msg=$msg raw=$rawError")
                    Toast.makeText(this@DashboardActivity, "Load failed: $code", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                android.util.Log.e("DBG_DASH", "Exception loading dashboard", e)
                Toast.makeText(this@DashboardActivity, "Exception: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun bindDashboard(data: DashboardResponse) {
        // ---------- Avatar loading ----------
        val avatar = data.employee.avatarUrl
        if (!avatar.isNullOrBlank()) {
            val finalUrl = when {
                avatar.startsWith("http", true) -> avatar
                avatar.startsWith("/") -> RetrofitClient.BASE_URL.trimEnd('/') + avatar
                else -> RetrofitClient.BASE_URL.trimEnd('/') + "/$avatar"
            }

            Glide.with(this)
                .load(finalUrl)
                .placeholder(R.drawable.ic_launcher_foreground)
                .error(R.drawable.ic_launcher_foreground)
                .circleCrop()
                .into(imgAvatar)
        } else {
            imgAvatar.setImageResource(R.drawable.ic_launcher_foreground)
        }

        // ---------- Rest of UI binding ----------
        tvEmployeeName.text = data.employee.fullName
        tvEmployeeCodeTitle.text =
            "${data.employee.employeeCode} · ${data.employee.jobTitle ?: ""}"

        tvTodayTime.text = data.todayStatus.checkInTime ?: "Not checked in"

        btnCheckInOut.text = when {
            data.todayStatus.canCheckIn -> "Check In"
            data.todayStatus.canCheckOut -> "Check Out"
            else -> "Completed"
        }
        btnCheckInOut.isEnabled =
            data.todayStatus.canCheckIn || data.todayStatus.canCheckOut

        tvLeaveBalanceDays.text = "${data.leaveSummary.leaveBalanceDays} days"
        tvLeaveThisMonthDays.text = "${data.leaveSummary.usedThisMonthDays} days"

        adapter.submitList(data.recentActivities)
    }

    private fun handleCheckButton() {
        val token = sessionManager.fetchAuthToken()
        if (token.isNullOrEmpty()) return

        val action = if (btnCheckInOut.text.toString().contains("In", true))
            "CHECK_IN" else "CHECK_OUT"

        // include optional user id header
        val userIdHeader = sessionManager.fetchUserId()?.toString()

        lifecycleScope.launch {
            try {
                val resp: Response<SimpleResponse> = RetrofitClient.dashboardApi.checkInOut(
                    "Bearer $token",
                    userIdHeader,
                    CheckInOutRequest(action)
                )

                if (resp.isSuccessful) {
                    val body = resp.body()
                    if (body != null) {
                        Toast.makeText(this@DashboardActivity, body.message, Toast.LENGTH_SHORT).show()
                        loadDashboard()
                    } else {
                        Toast.makeText(
                            this@DashboardActivity,
                            "Action completed (empty server response)",
                            Toast.LENGTH_SHORT
                        ).show()
                        loadDashboard()
                    }
                } else {
                    val serverError = try {
                        resp.errorBody()?.string()
                    } catch (e: Exception) {
                        null
                    }
                    val msg = serverError?.takeIf { it.isNotBlank() } ?: resp.message()
                    Toast.makeText(this@DashboardActivity, "Action failed: $msg", Toast.LENGTH_LONG)
                        .show()
                }
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(
                    this@DashboardActivity,
                    "Failed to update attendance",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }
}
