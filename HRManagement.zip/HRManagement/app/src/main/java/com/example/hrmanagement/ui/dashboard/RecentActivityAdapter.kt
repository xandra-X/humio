package com.example.hrmanagement.ui.dashboard

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.hrmanagement.R
import com.example.hrmanagement.data.RecentActivity

class RecentActivityAdapter :
    ListAdapter<RecentActivity, RecentActivityAdapter.ViewHolder>(DiffCallback) {

    // Use some stable way to tell items apart
    object DiffCallback : DiffUtil.ItemCallback<RecentActivity>() {
        override fun areItemsTheSame(oldItem: RecentActivity, newItem: RecentActivity): Boolean =
            oldItem.createdAt == newItem.createdAt && oldItem.type == newItem.type

        override fun areContentsTheSame(oldItem: RecentActivity, newItem: RecentActivity): Boolean =
            oldItem == newItem
    }

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val tvTitle: TextView = view.findViewById(R.id.tvActivityTitle)
        private val tvSubtitle: TextView = view.findViewById(R.id.tvActivitySubtitle)

        fun bind(item: RecentActivity) {
            // Be safe if backend sends null/blank fields
            val safeTitle = item.title?.takeIf { it.isNotBlank() }
                ?: item.type?.takeIf { it.isNotBlank() }
                ?: "Activity"

            val safeSubtitle = item.subtitle?.takeIf { it.isNotBlank() }
                ?: item.createdAt?.takeIf { it.isNotBlank() }
                ?: ""

            tvTitle.text = safeTitle
            tvSubtitle.text = safeSubtitle
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_recent_activity, parent, false)
        return ViewHolder(v)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }
}
